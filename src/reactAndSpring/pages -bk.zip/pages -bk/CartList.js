import axios from "axios";
import { useEffect, useState } from "react";
import { Button, Col, Container, Form, Image, Row, Table } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

function App({ user }) {
    console.log(`user`);
    console.log(user); //현재 접속자 정보 출력

    //사용자 정보가 바뀔때마다 렌더링합니다.
    //user?.id : optional chaining (물음표가 있어서 오류를 발생하지 않고 undefined를 반환)
    useEffect(() => {
        if (user && user?.id) {
            fetchCartProducts();

        }
    }, [user]);

    const navigate = useNavigate();

    /*특정 고객에 대한 카트 상품 목록 State */
    /*스프칭 부트의 CartProductResponseDto 클래스 참조 */
    const [cartProducts, setCartProducts] = useState([]);

    /*화면에 보여주는 주문 총 금액*/
    const [orderTotalPrice, setOrderTotalPrice] = useState(0);


    /*특정 고객에 대한 카트 상품 목록을 조회합니다.*/
    const fetchCartProducts = async () => {
        console.log(`카트 상품 불러 오기 시작`);
        try {
            const url = `http://localhost:9000/cart/list/${user.id}`;
            const response = await axios.get(url);
            setCartProducts(response.data || []);

            console.log(`카트 상품 응답 결과`);
            console.log(response.data);


        } catch (error) {
            alert('카트 상품 데이터 정보를 가져오지 못했습니다. ');
            console.log(`오류정보: ${error}`);
            navigate(`/product/list`);
        };



    };

    //전체 선택 체크박스를 Toggle했습니다.
    const toggleAllCheckBox = (allCheckBoxStatus) => {
        console.log(`전체 선택 체크 박스 ${allCheckBoxStatus}`);


        setCartProducts((previousProducts) => {
            //모든 상품들의 체크 상태를 `전체 선택` 체크 박스의 상태와 동일하게 설정 
            const updatedProducts = previousProducts.map((product) => ({
                ...product,
                checked: allCheckBoxStatus
            }));

            //총 주문 금액을 갱신합니다.
            //비동기 렌더링 문제로 수정된 updatedProducts항목을 매개변수로 넘겨주어야 정상 작동합니다.
            refreshOrderTotalPrice(updatedProducts);


            return updatedProducts;

        });
    }

    // //총 주문 금액을 재계산해주는 함수입니다.
    // const calculateTotalPrice = (products) => {
    //     return 0;
    // };

    //개별 체크 박스의 값을 toggle 했습니다.
    const toggleCheck = (cartProductId) => {
        console.log(`카트 상품 아이디: ${cartProductId}`);

        setCartProducts((previousProducts) => {
            //해당 상품의 checked 상태를 반전시킵니다.
            const updatedProducts = previousProducts.map((product) =>
                //여러개의 목록 중에서 카트상품 아이디가 동일한 항목에 대해서만 !연산자로 상태 반전
                product.cartProductId === cartProductId
                    ? { ...product, checked: !product.checked }
                    : product

            );

            //총 주문 금액을 갱신합니다.
            //비동기 렌더링 문제로 수정된 updatedProducts항목을 매개변수로 넘겨주어야 정상 작동합니다.
            refreshOrderTotalPrice(updatedProducts);

            return updatedProducts;

        });


    };

    //카트 상품 목록 중 특정 상품의 구매 수량을 변경하고자 합니다.
    const changeQuantity = async (cartProductId, quantity) => {


        console.log(`카트 상품 아이디: ${cartProductId}, 변경 수량: ${quantity}`);

        if (quantity === "") {
            quantity = 0

        }

        try {
            /*patch() 동작은 전체가 아닌 일부 데이터만 변경을 수행하고자 할 때 사용됩니다.*/
            /*스프링 부트의 webconfig 클래스 내 addCorsMappings() 메소드 참조 바람 */
            /* cartProductId: 카트 상품 아이디, quantity: 변경수량 */
            const url = `http://localhost:9000/cart/edit/${cartProductId}?quantity=${quantity}`;
            const response = await axios.patch(url);

            console.log(response.data || '');

            //금액 cartproducts();의
            setCartProducts((previousProducts) =>{
                //previousProducts : 갱신전 카트 상품 데이터
               const updatedProducts = previousProducts.map((product) =>
                    //방금 내가 수정한 카트 상품 아이디와 동일하면 , 전개연산자를 이용하여 해당 삼품의 quantity 갱신
                    product.cartProductId === cartProductId ? { ...product, quantity: quantity === 0 ? "" : quantity } : product)
                    refreshOrderTotalPrice(updatedProducts);
                    return updatedProducts

        });
                    


            
            

        } catch (error) {
            console.log(`카트 상품 수량 변경 실패`);
            console.log(error);

        }
    };

    const refreshOrderTotalPrice = (products) => {
        console.log(`요금 재 계산 시작`);

        let total = 0;
        products.forEach((bean)=>{
            if(bean.checked){
                total += bean.price * bean.quantity; // 총 금액 누적
            }
        });
        setOrderTotalPrice(total); //상태 업데이트

    }

    //카트 상품 아이디를 이용하여 해당 품목을 목록에서 배제합니다.
    const deleteCartProduct = async (cartProductId) => {
        //삭제 확인 컨펌 함수
        const isConfirmed = window.confirm('해당 카트 상품을 정말로 삭제하시겠습니까?');

        if (isConfirmed) {
            console.log(`삭제할 카트 상품 아이디: ${cartProductId}`);
            
            try {
                //backend에게 삭제 요청
                const url = `http://localhost:9000/cart/delete/${cartProductId}`;
                const response = await axios.delete(url);

                //카트 상품 목록 갱신하고 요금을 다시 계산합니다.
                setCartProducts((previousProducts) =>{
                    //삭제된 품목을 제외한 갱신된 카트 상품들
                    const updatedProducts= previousProducts.filter((product)=> product.cartProductId !== cartProductId)
                refreshOrderTotalPrice(updatedProducts);
                
             

                return updatedProducts;

                });
            
            alert(response.data);

            } catch (error) {
                console.log(`카트 상품 삭제 기능 오류`);
                console.log(error);


            };
        } else {
            console.log(`카트 상품 삭제가 취소 되었습니다.`)

        }


    };

    const orders = async () => {
        console.log(`주문 로직 시작`);
        
        const selectedproducts = cartProducts.filter((bean)=> bean.checked);
        if(selectedproducts.length === 0 ){

            alert(`주문할 상품을 선택해 주세요.`)
            return;
        }
        try {
            const url = `http://localhost:9000/cart/order`;
            //스프링부트의 OrderItemDto, OrderRequestDto 클래스와 연관있습니다.
            const data= {
                memberId:user.id,
                status:`PENDING`,
                orderItems: selectedproducts.map((product) =>({
                    cartProductId:product.cartProductId,
                    productId: product.productId,
                    quantity: product.quantity
            }))

            } ;
            console.log(`주문할 데이터 정보`);
            console.log(data);
           const response = await axios.post(url, data);
           alert(response.data)

           //주문한 상품을 장바구니에서 제거 또는 선택 해제
        setCartProducts((prevProudcts)=>
        prevProudcts.filter((product)=>!product.checked)); //주문한 상품 제거

        //총 주문 금액 초기화
        setOrderTotalPrice(0);


        } catch (error) {
            console.log(`주문하기 기능 오류`);
            console.log(error);

        };

    };

    return (
        <Container className="mt-4">
            <h2 className="me-4">{user?.name}님의 장바구니</h2>
            <Table striped bordered hover responsive>
                <thead>
                    <tr>
                        <th>
                            <Form.Check
                                type="checkbox"
                                onChange={(event) => toggleAllCheckBox(event.target.checked)}
                                label='전체 선택' />
                        </th>
                        <th>상품정보</th>
                        <th>수량</th>
                        <th>금액</th>
                        <th>삭제</th>
                    </tr>
                </thead>
                <tbody>
                    {cartProducts.length > 0 ? (
                        cartProducts.map((product) => (
                            <tr key={product.cartProductId}>
                                <td className="text-center align-middle">
                                    <Form.Check
                                        type="checkbox"
                                        checked={product.checked}
                                        onChange={() => toggleCheck(product.cartProductId)}
                                    />
                                </td>
                                <td className="text-center align-middle">

                                    <Row>
                                        {/*한칸에 이미지 4, 상품 이름  8로 공간 할당 */}
                                        <Col xs={4}>
                                            <Image src={`http://localhost:9000/images/${product?.image}`}
                                                thumbnail
                                                alt={product.name}
                                                width="80" height="80" />
                                        </Col>
                                        <Col xs={8} className="d-flex align-items-center">
                                            {product.name}
                                        </Col>
                                    </Row>
                                </td>
                                <td className="text-center align-middle">
                                    <Form.Control
                                        type="number"
                                        min={1}
                                        value={product.quantity}
                                        onChange={(event) => changeQuantity(product.cartProductId, (event.target.value))}
                                        style={{ width: '80px', margin: '0 auto' }}
                                    />

                                </td>
                                <td className="text-center align-middle">
                                    {(product.price * product.quantity).toLocaleString()}원
                                </td>
                                <td className="text-center align-middle">
                                    <Button variant="danger" size="sm" onClick={() => deleteCartProduct(product.cartProductId)}>
                                        삭제
                                    </Button>
                                </td>

                            </tr>

                        ))

                    ) : (
                        <tr><td>장바구니(카트)가 비어있습니다.</td></tr>
                    )}

                </tbody>

            </Table>
            <h3 className="text-end mt-3">총 주문 금액: {orderTotalPrice.toLocaleString()} 원</h3>
            <div className="text-end">
                <Button variant="primary" size="lg" onClick={orders}>
                    주문하기
                </Button>
            </div>

        </Container>
    );
};

export default App;