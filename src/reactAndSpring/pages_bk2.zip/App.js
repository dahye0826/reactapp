import 'bootstrap/dist/css/bootstrap.min.css'; //부트 스트랩 스타일
import { Container, Navbar, Nav } from 'react-bootstrap';


//웹 페이지 요청에 따른 라우팅 관련 코드드
import { BrowserRouter as Router, Routes, Route, useNavigate, Navigate } from 'react-router-dom';

//라우팅 관련된 컴포넌트트
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ProductList from './pages/ProductList';
import ProductDetail from './pages/ProductDetail';
import ProductInsertForm from './pages/ProductInsertForm';
import ProductUpdateForm from './pages/ProductUpdateForm';
import CartList from './pages/CartList';

import { useEffect, useState } from 'react';
import axios from 'axios';


function App() {
    // 로그인 여부를 알 수 있는 사용자 정보
    const [user, setUser] = useState(null);
    

   

    // 페이지 새로 고침시 로그인 상태를 localStorage에서 다시 읽어 오기.
    // 우리는 한 번만 rendering되어야 하므로, 빈 배열[]을 2번째 매개 변수로 넣어 줍니다.
    useEffect(() => {
        const loginUser = localStorage.getItem('user');
        setUser(JSON.parse(loginUser)); //로컬 스토리지에서 데이터 읽어 오기
    }, []);

    const handleLoginSuccess = (userData) => {
        // userData : 로그인 페이지에서 넘겨 주는 로그인한 사용자 정보
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
        console.log('로그인 축하해요');
    };

    const handleLogout = (event) => {
        event.preventDefault();
        axios.post("http://localhost:9000/member/logout")
            .then(() => {
                setUser(null); // 미로그인 상태로 변환
                localStorage.removeItem('user');
                console.log('로그 아웃 성공');
   
            })
            .catch((error) => {
                console.log('로그 아웃 실패', error)
            });

    };


    var MenuItems = () => {
        const navigate = useNavigate();

        
        //user가 유의미한 데이터면 role반환, user가 무의미한 데이터면 Undefined반환
        switch (user?.role) {
            case 'ADMIN':
                return (
                    <>
                        <Nav.Link onClick={()=> navigate('/product/list')}>상품 보기</Nav.Link>
                        <Nav.Link onClick={()=> navigate('/product/insert')}>상품 등록</Nav.Link>
                        <Nav.Link href='/member/login' onClick={handleLogout}>로그 아웃</Nav.Link>
                    </>
                );
            case 'USER':
                return (
                    <>
                       <Nav.Link onClick={()=> navigate('/product/list')}>상품 보기</Nav.Link>
                        <Nav.Link onClick={()=> navigate('cart/list')}>장바구니</Nav.Link>
                        <Nav.Link onClick={()=> navigate('order/list')}>주문 내역</Nav.Link>

                        <Nav.Link href='/member/login' onClick={handleLogout}>로그 아웃</Nav.Link>
                    </>
                );
            default:
                return (
                    <>
                     <Nav.Link onClick={()=> navigate('/product/list')}>상품 보기</Nav.Link>
                     <Nav.Link onClick={()=> navigate('/product/login')}>로그인</Nav.Link>
                     <Nav.Link onClick={()=> navigate('/product/signup')}>회원가입</Nav.Link>
                    </>
                );
        }
    };

    return (
        <Router>
            {/*상단 네비게이션 바*/}
            <Navbar bg='dark' variant='dark' expand='lg'>
                <Container>
                    <Navbar.Brand href='/'>
                        Ict coffee shop
                    </Navbar.Brand>
                    <Nav className="me-auto">
                        <MenuItems />
                    </Nav>
                </Container>
            </Navbar>

            {/*path에는 요청 url 정보, element에는 컴포넌트 이름*/}
            
            <Routes>
            <Route path='/' element={<HomePage />} />{/*홈 페이지*/}
                    <Route path='/product/login' element={<LoginPage setUser={handleLoginSuccess} />} /> {/*setUser={''} 하위 컴포넌트에게 넘겨줄 프로퍼티이다.*/}
                    <Route path='/product/signup' element={<SignupPage />} />

                    {/*로그인 여부에 따라서 상품 목록 페이지가 다르게 보여야 하므로, user를 넘겨줍니다.*/}
                  
                    <Route path='/product/list' element={<ProductList user={user} />} />

                    {/*장바구니 목록 페이지(user 넘겨줌)*/}
                    <Route path='/cart/list' element={<CartList user={user} />} />
    

                     {/*미로그인시 장바구니와 구매하기 기능은 선택 불가능해야하므로, user를 넘겨줍니다.*/}
                    <Route path='/product/detail/:id' element={<ProductDetail user={user} />} />
                    <Route path='/product/insert' element={<ProductInsertForm />} />
                    <Route path='/product/update/:id' element={<ProductUpdateForm />} />
                </Routes>


            {/* 푸터 */}
            <footer className="bg-dark text-light text-center py-3 mt-5">
                <p>© 2025 ICT Coffee Shop. All rights reserved.</p>
            </footer>
        </Router>
    );
}
export default App;