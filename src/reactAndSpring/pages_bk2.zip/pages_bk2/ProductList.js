import axios from "axios";
import { useEffect, useState } from "react";
import { Container, Row, Col, Card, Button, Pagination, Form } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";



function App({ user }) {
    /* user === 'ADMIN' 이면 [상품등록] , 수저으 삭제 메뉴가 보여야합니다. */
    const [products, setProducts] = useState([]);//상품 목록 state


    const [search, setSearch] = useState({
        period: "전체기간",
        category: "전체 카테고리",
        type: "전체 검색",
        keyword: "",
    });

    const searchHandler = (event) => {
        setSearch({
            ...search, [event.target.name]: event.target.value
        })
    };

    const searchProduct = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.post("http://localhost:9000/product/search", 
            search,   
            { headers: { "Content-Type": "application/json" } }
            )
            console.log(response.data);
            
        }catch(error){
            console.error("검색 요청 실패", error)

        }
    }


        const [paging, setPaging] = useState({
            totalElements: 0, //전체 데이터 개수
            totalPages: 0, // 전체 페이지 번호
            pageNumber: 0, //현재 페이지 번호
            pageSize: 6, //한페이지에 보여주고자 하는 데이터 개수
            beginPage: 0, // 페이지 시작 번호
            endPage: 0, // 페이지 끝 번호
            pageCount: 10 //페이지 하단 버튼 개수

            // beginPage:11, // 페이지 시작 번호
            // endPage:17// 페이지 끝 번호 를 구해주는 공식 도출하기


        });

        useEffect(() => { //backend 서버에서 데이터읽어오기
            // axios.get("http://localhost:9000/product/list") //전체가져오기
            const url = `http://localhost:9000/product/list?pageNumber=${paging.pageNumber}&pageSize=${paging.pageSize}`;
            axios.get(url)
                .then((response) => {
                    // console.log('response.data');
                    // console.log(`응답받은 데이터`)
                    console.log(response.data)
    
    
                    setProducts(response.data.content || []);//안전한 기본 값 설정
    
                    //페이징 정보를 업데이트 합니다.
                    setPaging((prev) => {
    
                        const totalElements = response.data.totalElements;
                        const totalPages = response.data.totalPages;
                        const pageNumber = response.data.pageable.pageNumber;
    
                        //pagesize 이 값은 고정적이므로 할당 받지 않아도 무방합니다.
                        //단 pagesize가 가변적인 경우 반드시 다시 할당 해야합니다.
                        const pageSize = response.data.pageable.pageSize;
    
                        const beginPage = Math.floor(prev.pageNumber / prev.pageCount) * prev.pageCount;
                        const endPage = beginPage + prev.pageCount - 1;
                        //pageCount: 10 //고정값으로 그냥 진행
    
                        console.log(pageNumber);
    
                        return {
                            ...prev,
                            totalElements: totalElements,
                            totalPages: totalPages,
                            pageNumber: pageNumber,
                            pageSize: pageSize,
                            beginPage: beginPage,
                            endPage: endPage,
    
                        }
    
                    });
                })
                .catch((error) => {
                    console.error(error);
                });
    
        }, [paging.pageNumber, paging.pageSize]); //페이지 변호가 변경될때 마다 다시 redering되어야합니다. 
        //2번째 매개 변수 []로 인하여 딱 1번만 rendering 합니다.
    



        const navigate = useNavigate();
        console.log(paging)
        return (
            <Container className="my-4">
                <h1 className="my-4">상품 목록 페이지</h1>
                <Link to={`/product/insert`}>
                    {user?.role === 'ADMIN' && (<Button variant="primary" className="mb-3">상품 등록 </Button>)}

                </Link>
                <Row>
                    {products.map((product) => (
                        <Col key={product.id} md={4} className="mb-4">
                            <Card className="h-100"
                                onClick={() => navigate(`/product/detail/${product.id}`)}
                                //바깥 {} jsx 문법 안{} 자바스크립트
                                style={{ cursor: 'pointer' }}
                            >
                                <Card.Img
                                    variant="top"
                                    src={`http://localhost:9000/images/${product.image}`}
                                    alt={product.name}
                                    style={{ width: '100%', height: '200px', objectfit: 'cover' }}

                                />
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <Card.Text>가격:{product.price}원</Card.Text>

                                    {user?.role === 'ADMIN' && (<div className="d-flex justify-content-center">

                                        <Button
                                            variant="warning"
                                            className="me-2"
                                            onClick={(event) => {
                                                event.stopPropagation();//card click event 방지
                                                navigate(`/product/update/${product.id}`);

                                            }}
                                        >
                                            수정
                                        </Button>


                                        <Button variant="danger" className="me-2">삭제</Button>


                                    </div>
                                    )}




                                </Card.Body>

                            </Card>

                        </Col>
                    ))}

                </Row>

                {/*페이징 처리 영역*/}
                <Pagination className="custom-pagination justify-content-center mt-4">
                    {/*앞쪽 영역*/}
                    <Pagination.First
                        onClick={() => {
                            console.log(`Fist 버튼 페이지: 0 페이지로 이동`);
                            setPaging((prev) => ({ ...prev, pageNumber: 0 }));
                        }}
                        disabled={paging.pageNumber < paging.pageCount}
                        as="button"
                    >
                        맨처음
                    </Pagination.First>

                    <Pagination.Prev
                        onClick={() => {
                            const gotoPrevPage = paging.beginPage - 1;
                            console.log(`Prev 버튼 클릭 : ${gotoPrevPage} 페이지로 이동`);
                            setPaging((prev) => ({ ...prev, pageNumber: gotoPrevPage }));
                        }}
                        disabled={paging.pageNumber < paging.pageCount}
                        as="button"
                    >
                        이전
                    </Pagination.Prev>

                    {/*숫자로 반복되는 영역*/}
                    {[...Array(paging.endPage - paging.beginPage + 1)].map((_, idx) => {
                        const pageIndex = paging.beginPage + idx + 1;
                        // console.log(pageIndex);
                        return (
                            <Pagination.Item
                                key={pageIndex}
                                active={paging.pageNumber === (pageIndex - 1)}
                                onClick={() => {
                                    console.log(`${pageIndex}페이지로 이동하기`);
                                    setPaging((prev) => ({ ...prev, pageNumber: (pageIndex - 1) }));
                                }}
                            >
                                {pageIndex}
                            </Pagination.Item>
                        )
                    })}

                    {/*뒷쪽 영역*/}

                    <Pagination.Next
                        onClick={() => {
                            const gotoNextPage = paging.endPage + 1;
                            console.log(`Next 버튼 클릭 : ${gotoNextPage} 페이지로 이동`);
                            setPaging((prev) => ({ ...prev, pageNumber: gotoNextPage }));
                        }}
                        disabled={paging.pageNumber >= Math.floor(paging.totalPages / paging.pageCount) * paging.pageCount}
                        as="button"
                    >
                        다음
                    </Pagination.Next>

                    <Pagination.Last
                        onClick={() => {
                            const lastPage = paging.totalElements - 1;
                            console.log(`Last 버튼 페이지: {lastPage} 페이지로 이동`);
                            setPaging((prev) => ({ ...prev, pageNumber: lastPage }));
                        }}
                        disabled={paging.pageNumber >= Math.floor(paging.totalPages / paging.pageCount) * paging.pageCount}
                        as="button"
                    >
                        맨끝
                    </Pagination.Last>
                </Pagination>
                <Form  onSubmit={searchProduct} >
                    <Row>
                        <Col>
                            <Form.Select size="sm"
                                name="period"
                                value={search.period}
                                onChange={searchHandler} >
                                <option>전체기간</option>
                                <option>1일</option>
                                <option>1주</option>
                                <option>1개월</option>
                                <option>6개월</option>
                            </Form.Select>
                        </Col>
                        <Col>
                            <Form.Select size="sm"
                                placeholder="--선택해주세요"
                                name="category"
                                value={search.category}
                                onChange={searchHandler}
                            >
                                <option>전체 카테고리</option>
                                <option>빵(BREAD)</option>
                                <option>음료수(BEVERAGE)</option>
                                <option>케익(CAKE)</option>
                            </Form.Select>
                        </Col>
                        <Col>
                            <Form.Select size="sm"
                                placeholder="선택하기"
                                name="keyword"
                                value={search.keyword}
                                onChange={searchHandler}>
                                <option>전체 검색</option>
                                <option>상품 이름(NAME)</option>
                                <option>상품 설명(description)</option>
                            </Form.Select>
                        </Col>
                        <Col>
                            <Form.Control placeholder="검색어를 입력해주세요."
                                name="type"
                                value={search.type}
                                onChange={searchHandler} />
                        </Col>
                        <Col>
                            <Button variant="dark" type="submit">검색</Button>
                        </Col>
                    </Row>
                </Form>

            </Container>
        )
    }
    export default App;